genisoimage -o ../myos.iso -input-charset utf-8 -b 'isolinux.bin' -no-emul-boot -boot-load-size 4  -boot-info-table ./ 

