qemu-system-i386 -cdrom ../myos.iso

